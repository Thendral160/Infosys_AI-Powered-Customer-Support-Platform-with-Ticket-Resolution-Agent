from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
from models.schemas import Ticket, PipelineResponse
from rag.pipeline import run_pipeline, KNOWLEDGE_BASE

app=FastAPI(title="SupportPilot – AI Ticket Resolution Agent", version="2.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/")
def root(): return {"service":"SupportPilot","status":"online","pipeline":"Ticket → Analyze → Retrieve → Context → LLM/Generator → Resolution"}

@app.get("/health")
def health(): return {"status":"healthy","knowledge_base_documents":len(KNOWLEDGE_BASE)}

@app.get("/knowledge-base")
def knowledge_base(): return KNOWLEDGE_BASE

@app.post("/api/tickets/analyze", response_model=PipelineResponse)
def analyze(ticket: Ticket):
    result=run_pipeline(ticket)
    return {"ticket":ticket, **result}

app.mount("/static", StaticFiles(directory=Path(__file__).resolve().parent / "static"), name="static")
