import json
from config import KB_PATH, MIN_RELEVANCE
from .analyzer import analyze_ticket
from .retriever import KnowledgeRetriever
from .generator import build_context, generate_resolution

with open(KB_PATH, encoding="utf-8") as f: KNOWLEDGE_BASE=json.load(f)
retriever=KnowledgeRetriever(KNOWLEDGE_BASE)

def run_pipeline(ticket):
    analysis=analyze_ticket(ticket)
    results=retriever.search(analysis["query"],3)
    results=[d for d in results if d["score"] >= MIN_RELEVANCE]
    context=build_context(results)
    if not results:
        return {"status":"ESCALATED","analysis":analysis,"retrieved_documents":[],"context":"","resolution":"No sufficiently relevant knowledge-base articles were found. Please route this ticket to human support for investigation.","llm_used":False,"escalation_reason":f"No retrieved document met relevance threshold {MIN_RELEVANCE:.2f}."}
    resolution,llm_used=generate_resolution(ticket,results,context)
    status="RESOLVED" if resolution and "additional investigation is required" not in resolution.lower() else "ESCALATED"
    return {"status":status,"analysis":analysis,"retrieved_documents":results,"context":context,"resolution":resolution,"llm_used":llm_used,"escalation_reason":None if status=="RESOLVED" else "Knowledge base did not provide enough support for a safe automatic resolution."}
