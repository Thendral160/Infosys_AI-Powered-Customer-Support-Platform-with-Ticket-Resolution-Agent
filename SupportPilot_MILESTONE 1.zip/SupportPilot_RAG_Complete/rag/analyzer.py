RULES = {
    "VPN / Network Issue": ["vpn", "virtual private", "vpn client"],
    "Password Reset": ["password", "forgot password", "reset password", "cannot sign in", "login"],
    "Network Connectivity": ["network", "wifi", "wi-fi", "internet", "connectivity", "ethernet", "dns"],
    "Software Troubleshooting": ["software", "application", "app", "install", "installation", "launch", "not opening", "error when i start"],
    "Hardware Problem": ["hardware", "laptop", "keyboard", "mouse", "monitor", "printer", "device", "screen"],
    "System Error": ["system error", "blue screen", "system failure", "crash", "operating system"]
}

def analyze_ticket(ticket):
    text = f"{ticket.title} {ticket.description}".lower()
    scores = {k:0 for k in RULES}
    matched = []
    for category, words in RULES.items():
        for word in words:
            if word in text:
                scores[category] += 3 if len(word) > 6 else 2
                matched.append(word)
    category, best = max(scores.items(), key=lambda x:x[1])
    if best == 0:
        category, confidence = "Unclassified", 0.45
    else:
        confidence = min(0.98, 0.86 + best*0.02)
    return {"category":category,"confidence":round(confidence,2),"keywords":sorted(set(matched)),"query":text}
