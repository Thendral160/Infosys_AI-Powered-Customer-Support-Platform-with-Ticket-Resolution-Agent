from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class KnowledgeRetriever:
    def __init__(self, documents):
        self.documents = documents
        texts = [d["title"] + " " + d["category"] + " " + d["content"] for d in documents]
        self.vectorizer = TfidfVectorizer(stop_words="english")
        self.vectors = self.vectorizer.fit_transform(texts)

    def search(self, query, top_k=3):
        q = self.vectorizer.transform([query])
        scores = cosine_similarity(q, self.vectors)[0]
        ranked = scores.argsort()[::-1][:top_k]
        out=[]
        for i in ranked:
            if float(scores[i]) <= 0: continue
            doc=dict(self.documents[i]); doc["score"]=round(float(scores[i]),4); out.append(doc)
        return out
