import re
import requests
from config import LLM_API_URL, LLM_API_KEY, LLM_MODEL

def build_context(results):
    parts=[]
    for d in results:
        parts.append(f"SOURCE: {d['id']}\nTITLE: {d['title']}\nRELEVANCE: {d['score']:.2f}\n{d['content']}")
    return "\n\n==============================\n\n".join(parts)

def _local_grounded(results):
    steps=[]
    for d in results:
        for line in d["content"].splitlines():
            if re.match(r"^\d+\.\s+", line.strip()):
                step=re.sub(r"^\d+\.\s+", "", line.strip())
                if step not in steps: steps.append(step)
    if not steps:
        return "No approved troubleshooting steps were found in the retrieved knowledge base. Additional investigation is required.", False
    lines=["Recommended Resolution:"]+[f"{i}. {s}" for i,s in enumerate(steps[:6],1)]
    lines.append("\nSources: " + ", ".join(f"{d['id']} – {d['title']}" for d in results))
    return "\n".join(lines), False

def generate_resolution(ticket, results, context):
    if not results: return "No sufficiently relevant knowledge-base information was found. Additional investigation is required.", False
    if not (LLM_API_URL and LLM_API_KEY and LLM_MODEL):
        return _local_grounded(results)
    prompt=f"""You are an enterprise IT support assistant. Use ONLY the supplied knowledge base. Do not invent company-specific policies. Provide a concise numbered troubleshooting resolution, explain the likely cause when supported, and cite the KB source beside each step. If the knowledge base is insufficient, say additional investigation is required.

TICKET
Title: {ticket.title}
Description: {ticket.description}
Priority: {ticket.priority}

KNOWLEDGE BASE
{context}"""
    try:
        r=requests.post(LLM_API_URL, headers={"Authorization":f"Bearer {LLM_API_KEY}","Content-Type":"application/json"}, json={"model":LLM_MODEL,"messages":[{"role":"user","content":prompt}],"temperature":0.1}, timeout=30)
        r.raise_for_status(); data=r.json(); text=data["choices"][0]["message"]["content"].strip()
        return text, True
    except Exception:
        return _local_grounded(results)
