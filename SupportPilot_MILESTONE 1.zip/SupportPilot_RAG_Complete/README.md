# SupportPilot – Complete RAG Ticket Resolution Agent

This implementation follows the supplied Milestone 2 flow:

**Ticket → Ticket Analysis & Query Generation → Knowledge Base Retrieval → Context Augmentation → LLM/Resolution Generation → Response**

## Structure
```
supportpilot/
├── app.py
├── config.py
├── data/
│   └── knowledge_base.json
├── rag/
│   ├── __init__.py
│   ├── analyzer.py
│   ├── retriever.py
│   ├── generator.py
│   └── pipeline.py
├── models/
│   └── schemas.py
├── static/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── tests/
├── requirements.txt
└── .env.example
```

## Run in VS Code
1. Open this folder in VS Code.
2. Create environment: `python -m venv .venv`
3. Activate Windows: `.venv\Scripts\activate`
4. Install: `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` if you want a real LLM provider.
6. Start API: `uvicorn app:app --reload`
7. Open `http://127.0.0.1:8000/docs` for Swagger or `http://127.0.0.1:8000/static/index.html` for the dashboard.

## Real LLM
The project supports an OpenAI-compatible chat-completions endpoint through environment variables `LLM_API_URL`, `LLM_API_KEY`, and `LLM_MODEL`. Without those variables, it uses a local grounded generator that extracts approved steps from retrieved KB documents. This makes the demo runnable without an API key while preserving the RAG architecture.

## Testing
Run `pytest` after installing pytest (`pip install pytest`).

## Important
The 92%, 78%, and 3.2s figures in the UI are illustrative demo metrics matching the supplied design. They are not claimed measured results. For evaluation, replace them with metrics calculated from your test dataset.
