from typing import Optional, List
from pydantic import BaseModel, Field

class Ticket(BaseModel):
    title: str = Field(min_length=3)
    description: str = Field(min_length=3)
    priority: str = "Medium"
    category: Optional[str] = None

class Document(BaseModel):
    id: str
    title: str
    category: str
    content: str
    score: float

class PipelineResponse(BaseModel):
    status: str
    ticket: Ticket
    analysis: dict
    retrieved_documents: List[Document]
    context: str
    resolution: str
    llm_used: bool
    escalation_reason: Optional[str] = None
