const API=location.origin;
async function submitTicket(){
 const title=document.getElementById('title').value.trim(), description=document.getElementById('description').value.trim(), priority=document.getElementById('priority').value;
 const status=document.getElementById('status');
 if(!title||!description){status.textContent='Please enter both a title and description.';status.style.color='#d68a12';return}
 status.textContent='Analyzing ticket → retrieving knowledge → generating resolution...';status.style.color='#2376c9';
 try{const r=await fetch(API+'/api/tickets/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title,description,priority})});if(!r.ok)throw new Error('Backend error');const d=await r.json();render(d);status.textContent=d.status==='RESOLVED'?'✓ Solution generated successfully.':'⚠ Ticket escalated for human investigation.';status.style.color=d.status==='RESOLVED'?'#1ba565':'#d78b17'}catch(e){status.textContent='Cannot connect to backend. Start FastAPI and try again.';status.style.color='#d04b4b'}}
function render(d){
 document.getElementById('ticketInfo').innerHTML=`<div class="tickethead"><span class="ticketid">#T-${Date.now().toString().slice(-6)}</span><span class="pill">${d.status}</span><h3>${esc(d.ticket.title)}</h3><p>${esc(d.ticket.description)}</p><div class="meta">⚙ ${esc(d.analysis.category)} &nbsp; ❗ ${esc(d.ticket.priority)} &nbsp; 🎯 ${(d.analysis.confidence*100).toFixed(0)}% confidence</div><div class="query">⌕ ${esc(d.analysis.query)}</div></div>`;
 document.getElementById('docs').innerHTML=d.retrieved_documents.map(x=>`<div class="doc"><strong>${esc(x.title)}</strong> <span class="relevance">${(x.score*100).toFixed(0)}% relevance</span><p>${esc(x.content.split('\n')[0])}</p><small>${esc(x.id)} · ${esc(x.category)}</small></div>`).join('');
 document.getElementById('resolution').innerHTML=`<b>Generated Resolution ${d.llm_used?'· LLM':'· Knowledge-grounded generator'}</b><div>${esc(d.resolution)}</div>`;
 document.querySelectorAll('.workflow div').forEach(x=>x.style.fontWeight='700');
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
