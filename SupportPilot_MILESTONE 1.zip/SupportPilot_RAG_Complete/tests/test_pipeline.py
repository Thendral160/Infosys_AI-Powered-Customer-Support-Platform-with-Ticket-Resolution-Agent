from models.schemas import Ticket
from rag.pipeline import run_pipeline

def test_vpn_ticket():
    t=Ticket(title="VPN connection failing", description="Unable to connect to VPN since this morning. Connection timed out.", priority="High")
    r=run_pipeline(t)
    assert r["analysis"]["category"] in ("VPN / Network Issue","Network Connectivity")
    assert r["retrieved_documents"]
    assert "Recommended Resolution" in r["resolution"]

def test_password_ticket():
    t=Ticket(title="Forgot Windows password", description="I cannot sign in and need a password reset.")
    r=run_pipeline(t)
    assert r["retrieved_documents"]
