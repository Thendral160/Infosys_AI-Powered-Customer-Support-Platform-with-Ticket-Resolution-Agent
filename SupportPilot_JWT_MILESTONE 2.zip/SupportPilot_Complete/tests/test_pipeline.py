from backend.main import Ticket, analyze, retrieve

def test_vpn_retrieval():
    docs = retrieve("VPN connection timeout on corporate network", 2)
    assert docs
    assert docs[0].id == "KB001"

def test_vpn_resolution():
    result = analyze(Ticket(title="VPN Connection Failing", description="Unable to connect to VPN since this morning. Connection timed out.", priority="High"))
    assert result.status == "RESOLVED"
    assert result.confidence >= 0.90
    assert "KB001" in result.resolution
