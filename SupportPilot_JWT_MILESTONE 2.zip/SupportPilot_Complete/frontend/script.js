const KB={
 vpn:{category:'VPN / Network Issue',severity:'High',docs:['VPN Troubleshooting Guide','Network Firewall Configuration','VPN Authentication Problems'],steps:['Verify that your internet connection is active.','Open the VPN client and verify the configured server address and connection profile.','Check that your username, password and MFA authentication are valid.','If this is a corporate network, verify that VPN traffic is permitted by the firewall.','Restart the VPN client or VPN service and try connecting again.','If the issue continues, test from another network and contact IT support with the exact error message.']},
 password:{category:'Password Reset',severity:'Medium',docs:['Password Reset Guide','Authentication Procedures'],steps:['Open the organization-approved password reset page or process.','Complete the required identity verification or MFA step.','Create a new password that meets the organization password policy.','Sign in again using the new password.','If the reset fails or the account remains locked, contact IT support.']},
 network:{category:'Network Connectivity',severity:'High',docs:['Network Connectivity Guide','Corporate Network Troubleshooting'],steps:['Check whether Wi-Fi or Ethernet is enabled and connected.','Verify that the device has internet access by opening a trusted website.','Disconnect and reconnect to the corporate network.','Restart the network adapter or the device if the connection is still unavailable.','If other users are affected, report the outage to the network support team.']},
 software:{category:'Software Troubleshooting',severity:'High',docs:['Application Troubleshooting Guide','Software Installation Guide'],steps:['Close the application completely and open it again.','Restart the computer and retry the application.','Verify that the software installation completed successfully and that the required version is installed.','Record the exact error message and when it occurs.','If the application still fails, contact support with the error details and application version.']},
 hardware:{category:'Hardware Problem',severity:'Medium',docs:['Hardware Troubleshooting Guide','Device Support Guide'],steps:['Check that the affected device or peripheral is connected correctly.','Check power, cables and indicator lights where applicable.','Restart the affected device.','Reconnect the peripheral and test it again.','If the problem continues, provide the device or asset details to IT support.']},
 system:{category:'System Error',severity:'High',docs:['System Error Guide','Enterprise Support Procedures'],steps:['Record the exact error message or error code.','Save any important work and restart the affected application or device.','Retry the operation after the restart.','If the same error appears again, capture the time and steps that caused it.','Escalate the ticket to IT support for further investigation.']}
};
const seed=[
{id:'SP-1001',name:'Thendral',email:'thendral@example.com',title:'VPN is not working',desc:'I cannot connect to the office VPN.',impact:'High - Business affected',key:'vpn',status:'Resolved',created:'Today 09:42'},
{id:'SP-1002',name:'Arun Kumar',email:'arun@company.com',title:'Forgot Windows password',desc:'I forgot my Windows password and cannot sign in.',impact:'Medium - User affected',key:'password',status:'Resolved',created:'Today 09:18'},
{id:'SP-1003',name:'Sneha Thomas',email:'sneha@company.com',title:'Application error on launch',desc:'The new application is not opening and shows an error.',impact:'High - Business affected',key:'software',status:'Escalated',created:'Today 08:56'}
];
let tickets=JSON.parse(localStorage.getItem('sp_tickets')||'null')||seed;
let settings=JSON.parse(localStorage.getItem('sp_settings')||'null')||{classification:true,retrieval:true,generation:true,autoEscalate:true,notifications:true};
let page='dashboard';
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const save=()=>{localStorage.setItem('sp_tickets',JSON.stringify(tickets));localStorage.setItem('sp_settings',JSON.stringify(settings));};
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function toast(m){let t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function statusBadge(s){return `<span class="badge ${s==='Resolved'?'b-green':s==='Escalated'?'b-red':s==='Analyzing'?'b-amber':'b-blue'}">${s}</span>`}
function classify(text,impact){let t=text.toLowerCase();let scores={vpn:0,password:0,network:0,software:0,hardware:0,system:0};
const rules={vpn:['vpn','virtual private','vpn client','cannot connect to vpn'],password:['password','forgot password','reset password','cannot sign in','login password'],network:['network','wifi','internet','connectivity','office network','ethernet'],software:['software','application','app','install','installation','not opening','launch','error on launch'],hardware:['hardware','laptop','keyboard','mouse','monitor','printer','device'],system:['system error','blue screen','system failure','crash','operating system']};
Object.entries(rules).forEach(([k,words])=>words.forEach(w=>{if(t.includes(w))scores[k]+= w.length>6?3:2}));
let best=Object.entries(scores).sort((a,b)=>b[1]-a[1])[0]; if(best[1]===0)return {key:'system',confidence:62,reason:'No specific knowledge-base phrase matched'};
let confidence=Math.min(98,90+Math.min(8,best[1]*2)); if(best[0]==='network'&&scores.vpn>0) {best=['vpn',scores.vpn] ; confidence=96}
return {key:best[0],confidence,reason:'Strong keyword and intent match'};
}
function render(){updateCounts();renderDashboard();renderCreate();renderTickets();renderKnowledge();renderAgents();renderAnalytics();renderEscalations();renderSettings();if(page==='resolution' && window.lastResolution) renderResolution(window.lastResolution);else if(page==='resolution') page='dashboard';showPage(page)}
function updateCounts(){$('#ticketCount').textContent=tickets.length;$('#escCount').textContent=tickets.filter(t=>t.status==='Escalated').length}
function showPage(p){page=p;$$('.page').forEach(x=>x.classList.remove('active'));$('#'+p).classList.add('active');$$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===p));$('#title').textContent=p==='create'?'Create Support Ticket':p[0].toUpperCase()+p.slice(1)}
function makeSolution(data){ return (data.steps||[]).map((x,i)=>`${i+1}. ${x}`).join('\n'); }
function relevanceFor(key,index){ return Math.max(0.72 - index*0.09, 0.36); }

function renderDashboard(){let resolved=tickets.filter(t=>t.status==='Resolved').length, escs=tickets.filter(t=>t.status==='Escalated').length, rate=tickets.length?Math.round(resolved/tickets.length*100):0;$('#dashboard').innerHTML=`<div class="page-head"><div><h1>Good evening, ${esc((currentUser()||{}).name||'User')} 👋</h1><p>Monitor AI ticket resolution and help employees get unstuck faster.</p></div><button class="primary" onclick="showPage('create')">＋ Create Support Ticket</button></div><div class="cards"><div class="card kpi"><small>Total tickets</small><div class="num">${tickets.length}</div><span class="trend up">Live workspace</span></div><div class="card kpi"><small>AI resolved</small><div class="num">${rate}%</div><span class="trend up">Resolution rate</span></div><div class="card kpi"><small>Avg. AI response</small><div class="num">1.8s</div><span class="trend up">Solution generation</span></div><div class="card kpi"><small>Escalated</small><div class="num">${escs}</div><span class="trend ${escs?'red':'up'}">Human support</span></div></div><div class="grid2"><div class="card"><div class="card-title"><h3>Ticket activity</h3><small>Last 7 demo periods</small></div><div class="bar-chart">${[42,58,46,74,61,84,69].map((v,i)=>`<div class="bar"><i style="height:${v}%"></i><span>${['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][i]}</span></div>`).join('')}</div></div><div class="card"><div class="card-title"><h3>SupportPilot workflow</h3><small>AI pipeline</small></div><div class="workflow"><div class="wf"><span class="dot">1</span><div><b>Classify</b><small>Understand & categorize the ticket</small></div></div><div class="wf"><span class="dot">2</span><div><b>Retrieve</b><small>Find trusted knowledge using RAG</small></div></div><div class="wf"><span class="dot">3</span><div><b>Generate</b><small>Create a clear troubleshooting response</small></div></div><div class="wf"><span class="dot">4</span><div><b>Resolve / Escalate</b><small>Close with guidance or route to human support</small></div></div></div></div></div><div class="card" style="margin-top:18px"><div class="card-title"><h3>Recent tickets</h3><button class="secondary" onclick="showPage('tickets')">View all</button></div>${ticketTable(tickets.slice(0,5))}</div>`}
function ticketTable(arr){if(!arr.length)return '<div class="empty">No tickets yet. Create your first support ticket.</div>';return `<div class="table-wrap"><table class="table"><thead><tr><th>Ticket</th><th>Employee</th><th>Issue</th><th>Category</th><th>Severity</th><th>Status</th></tr></thead><tbody>${arr.map(t=>{let d=KB[t.key]||KB.system;return `<tr onclick="openTicket('${t.id}')" style="cursor:pointer"><td class="id">${esc(t.id)}</td><td>${esc(t.name)}</td><td><b>${esc(t.title)}</b><br><small style="color:#8a94a6">${esc(t.created)}</small></td><td>${esc(d.category)}</td><td>${severityBadge(d.severity)}</td><td>${statusBadge(t.status)}</td></tr>`}).join('')}</tbody></table></div>`}
function severityBadge(s){return `<span class="badge ${s==='High'?'b-red':s==='Medium'?'b-amber':'b-green'}">${s}</span>`}
function renderCreate(){ $('#create').innerHTML=`<div class="page-head"><div><h1>Create Support Ticket</h1><p>Describe your problem and SupportPilot will analyze it automatically.</p></div><span class="badge b-blue">AI workflow enabled</span></div><div class="create-layout"><div class="card form-card"><form id="ticketForm"><div class="form-grid"><div class="field"><label>Employee Name *</label><input id="fName" required placeholder="e.g. Thendral"></div><div class="field"><label>Email *</label><input id="fEmail" type="email" required placeholder="name@company.com"></div><div class="field full"><label>Ticket Title *</label><input id="fTitle" required placeholder="e.g. VPN is not working"></div><div class="field full"><label>Problem Description *</label><textarea id="fDesc" required placeholder="Explain the problem, when it started and what you already tried..."></textarea><div class="hint">Tip: Include the application/device and exact error when possible.</div></div><div class="field full"><label>Business Impact *</label><select id="fImpact"><option>Low - Individual inconvenience</option><option selected>Medium - User affected</option><option>High - Business affected</option><option>Critical - Business blocked</option></select></div></div><div class="form-footer"><button type="button" class="secondary" onclick="$('#ticketForm').reset()">Clear</button><button class="primary" type="submit">✦ Analyze & Submit Ticket</button></div></form></div><div class="ai-panel"><h2>🤖 AI-Powered Support</h2><p>SupportPilot analyzes every ticket through a transparent pipeline instead of only storing the request.</p>${['AI ticket categorization','Automatic severity detection','Knowledge retrieval (RAG)','Contextual solution generation','Ticket ID & status tracking','Human escalation when confidence is low'].map(x=>`<div class="feature"><b>✓</b>${x}</div>`).join('')}<div class="demo-box"><b>Accuracy-focused demo</b><small>Known support intents are mapped to trusted knowledge entries. When confidence is below 90%, the system does not claim a resolution and routes the case for human review.</small></div></div></div>`;$('#ticketForm').onsubmit=submitTicket}
async function submitTicket(e){
e.preventDefault();
let name=$('#fName').value.trim(),email=$('#fEmail').value.trim(),title=$('#fTitle').value.trim(),desc=$('#fDesc').value.trim(),impact=$('#fImpact').value;
let result=classify(title+' '+desc,impact); let key=result.key; let data=KB[key];
let id='SP-'+(1000+Math.max(1,...tickets.map(t=>parseInt(t.id.split('-')[1])||1000))+1);
let escalated=result.confidence<90||impact.startsWith('Critical');
let resolution=makeSolution(data), retrieved=data.docs.map((x,i)=>({id:'KB00'+String(i+1).padStart(1,'0'),title:x,score:relevanceFor(key,i)}));
// Use the real FastAPI RAG endpoint when it is running; keep a local fallback so the demo also works by opening index.html.
try{
 const r=await api('/analyze',{method:'POST',body:JSON.stringify({title,description:desc,priority:impact.startsWith('Critical')?'Critical':impact.startsWith('High')?'High':'Medium'})});
 if(r.ok){const apiResult=await r.json(); key=Object.keys(KB).find(k=>KB[k].category===apiResult.category)||key; data=KB[key]; result.confidence=Math.round(apiResult.confidence*100); escalated=apiResult.status==='ESCALATED'; resolution=apiResult.resolution || makeSolution(data); retrieved=apiResult.retrieved_documents||retrieved;}
}catch(err){if(err.message==='AUTH_EXPIRED')return; /* local RAG fallback if analysis API is temporarily unavailable */}
let t={id,name,email,title,desc,impact,key,status:escalated?'Escalated':'Resolved',created:new Date().toLocaleString([], {month:'short',day:'2-digit',hour:'2-digit',minute:'2-digit'}),confidence:result.confidence,resolution,retrieved};
tickets.unshift(t);save();updateCounts();
window.lastResolution={ticket:t,result,data,retrieved,resolution,elapsed:'1.8s'};
localStorage.setItem('sp_last_resolution',JSON.stringify(window.lastResolution));
renderResolution(window.lastResolution);showPage('resolution');toast(escalated?'Ticket analyzed and sent for human review':'Ticket analyzed — solution generated');
}
function showAnalysis(t,isNew=false,result=null,data=null){data=data||KB[t.key]||KB.system;result=result||{confidence:t.confidence||94,reason:'Stored classification'};let escalated=t.status==='Escalated';$('#modalBody').innerHTML=`<div class="modal-head"><div><div class="eyebrow" style="color:#3151d8">SUPPORTPILOT AI ANALYSIS</div><h2 style="margin:6px 0 4px">${esc(t.id)} — ${esc(t.title)}</h2><p style="margin:0;color:#7d879a;font-size:11px">${esc(t.name)} · ${esc(t.email)}</p></div><button class="close" onclick="closeModal()">✕</button></div><div class="analysis"><div class="analysis-card"><h4>CLASSIFICATION</h4><b>${esc(data.category)}</b></div><div class="analysis-card"><h4>SEVERITY</h4>${severityBadge(data.severity)}</div><div class="analysis-card"><h4>AI CONFIDENCE</h4><b>${result.confidence}%</b><small style="display:block;color:#7d879a;margin-top:4px">${esc(result.reason)}</small></div><div class="analysis-card"><h4>FINAL STATUS</h4>${statusBadge(t.status)}</div></div><div class="steps"><div class="step"><i>✓</i><div><b>Ticket Classification Agent</b><small>Identified ${esc(data.category)} from the employee's description.</small></div></div><div class="step"><i>✓</i><div><b>Knowledge Retrieval Agent</b><small>Retrieved: ${data.docs.map(esc).join(' · ')}</small></div></div><div class="step"><i>✓</i><div><b>${escalated?'Escalation Agent':'Resolution Agent'}</b><small>${escalated?'Confidence is below the safe resolution threshold or the business is critically blocked. Human support is required.':'A contextual response was generated from the retrieved support knowledge.'}</small></div></div></div><div class="solution"><h4>${escalated?'Human support required':'Generated solution'}</h4><p>${esc(escalated?'SupportPilot could not safely claim an automatic resolution for this ticket. The case has been routed to human support for investigation.':makeSolution(data))}</p></div><div class="modal-actions"><button class="secondary" onclick="closeModal();showPage('tickets')">View My Tickets</button>${escalated?'<button class="primary" onclick="closeModal();showPage(\'escalations\')">Open Escalation Queue</button>':'<button class="primary" onclick="closeModal();showPage(\'dashboard\')">Back to Dashboard</button>'}</div>`;$('#modal').classList.remove('hidden')}

function renderResolution(state){
 const t=state.ticket, result=state.result, data=state.data, docs=state.retrieved||[], escalated=t.status==='Escalated';
 const safe=docs.length?docs.slice(0,3):[];
 const sourceHtml=safe.map(d=>`<div class="source-row"><span class="source-dot">⌕</span><div><b>${esc(d.id||'KB')}</b><small>${esc(d.title||'Knowledge article')} · relevance ${Number(d.score||0).toFixed(2)}</small></div></div>`).join('');
 const raw=String(state.resolution||'').replace(/^Recommended Resolution:\s*/i,'').trim();
 const steps=raw.split(/\n/).map(x=>x.trim()).filter(Boolean).filter(x=>!/^Sources:/i.test(x));
 $('#resolution').innerHTML=`
 <div class="page-head"><div><div class="eyebrow">AI WORKSPACE · RAG PIPELINE</div><h1>Knowledge Retrieval &amp; Resolution Generation</h1><p>SupportPilot analyzed the new ticket, retrieved trusted knowledge and generated the next troubleshooting actions.</p></div><span class="badge ${escalated?'b-red':'b-green'}">${escalated?'Human review required':'AI resolution ready'}</span></div>
 <div class="cards"><div class="card kpi"><small>Retrieval confidence</small><div class="num">${Math.round((Math.max(...safe.map(d=>Number(d.score||0)),0))*100)}%</div><span class="trend up">Top knowledge match</span></div><div class="card kpi"><small>Resolution confidence</small><div class="num">${result.confidence}%</div><span class="trend ${result.confidence<90?'warn':'up'}">${result.confidence<90?'Below safe threshold':'Safe to resolve'}</span></div><div class="card kpi"><small>Response time</small><div class="num">${state.elapsed}</div><span class="trend up">Pipeline completed</span></div><div class="card kpi"><small>Ticket status</small><div style="margin-top:12px">${statusBadge(t.status)}</div><span class="trend ${escalated?'red':'up'}">${escalated?'Escalated':'Resolved'}</span></div></div>
 <div class="resolution-grid">
   <div class="card"><div class="card-title"><div><h3>Current Ticket</h3><small>${esc(t.id)}</small></div>${statusBadge(t.status)}</div><div class="ticket-preview"><b>${esc(t.title)}</b><p>${esc(t.desc)}</p><div class="ticket-meta"><span>Category: <b>${esc(data.category)}</b></span><span>Priority: <b>${esc(t.impact)}</b></span></div></div><div class="pipeline"><div class="pipeline-step done"><i>✓</i><div><b>Ticket Analysis</b><small>Problem understood and categorized as ${esc(data.category)}.</small></div></div><div class="pipeline-step done"><i>✓</i><div><b>Knowledge Retrieval</b><small>${safe.length} relevant knowledge article(s) retrieved using RAG.</small></div></div><div class="pipeline-step done"><i>✓</i><div><b>Context Augmentation</b><small>Retrieved troubleshooting information added as context.</small></div></div><div class="pipeline-step ${escalated?'warn-step':'done'}"><i>${escalated?'!':'✓'}</i><div><b>${escalated?'Escalation Agent':'Resolution Agent'}</b><small>${escalated?'The confidence is below the safe threshold, so human support must investigate.':'A solution was generated from the retrieved knowledge.'}</small></div></div></div></div>
   <div class="card ai-resolution-card"><div class="card-title"><div><h3>✦ AI Resolution</h3><small>${escalated?'Recommended action':'How to solve the problem'}</small></div><span class="badge b-blue">RAG</span></div><div class="solution-heading">${escalated?'Human support required':'Recommended troubleshooting steps'}</div><div class="solution-steps">${escalated?`<div class="escalate-note"><b>SupportPilot will not invent a solution.</b><p>No safe automatic resolution is available for this ticket. Review the retrieved knowledge and investigate manually.</p></div>`:steps.map((x,i)=>`<div class="solution-step"><span>${i+1}</span><div>${esc(x.replace(/^\d+\.\s*/,''))}</div></div>`).join('')}</div>${!escalated&&safe.length?`<div class="sources"><b>Knowledge used</b>${sourceHtml}</div>`:''}</div>
 </div>
 <div class="resolution-actions"><button class="secondary" onclick="showPage('create')">＋ Create Another Ticket</button><button class="secondary" onclick="showAnalysis(tickets.find(x=>x.id==='${esc(t.id)}'))">View Full AI Analysis</button><button class="primary" onclick="showPage('tickets')">View My Tickets</button></div>`;
}

function openTicket(id){let t=tickets.find(x=>x.id===id);if(t)showAnalysis(t)}function closeModal(){$('#modal').classList.add('hidden')}
function renderTickets(){$('#tickets').innerHTML=`<div class="page-head"><div><h1>My Tickets</h1><p>Every submitted request gets an ID, AI analysis and a trackable status.</p></div><button class="primary" onclick="showPage('create')">＋ New Ticket</button></div><div class="card">${ticketTable(tickets)}</div>`}
function renderKnowledge(){$('#knowledge').innerHTML=`<div class="page-head"><div><h1>Knowledge Base</h1><p>SupportPilot retrieves these trusted troubleshooting topics before generating a response.</p></div><span class="badge b-green">RAG ready</span></div><div class="kb-grid">${Object.values(KB).map(x=>`<div class="card kb-card"><div class="kb-icon">⌕</div><h3>${esc(x.category)}</h3><p>${esc(x.solution)}</p><div class="kb-meta"><span>${x.docs.length} knowledge topics</span><span>RAG ✓</span></div></div>`).join('')}</div>`}
function renderAgents(){$('#agents').innerHTML=`<div class="page-head"><div><h1>Multi-Agent AI</h1><p>Each agent has a clear responsibility in the ticket lifecycle.</p></div></div><div class="agent-grid">${[['✦','Ticket Classification Agent','Understands and categorizes the support request.',96],['⌕','Knowledge Retrieval Agent','Searches relevant organizational knowledge using RAG.',92],['◈','Resolution Agent','Generates relevant, contextual and easy-to-follow troubleshooting guidance.',94],['⚑','Escalation Agent','Routes low-confidence or unresolved cases to human support.',98]].map(x=>`<div class="card agent-card"><div class="kb-icon">${x[0]}</div><h3>${x[1]}</h3><p>${x[2]}</p><div class="metric"><span>Demo confidence</span><b>${x[3]}%</b></div><div class="progress"><i style="width:${x[3]}%"></i></div></div>`).join('')}</div>`}
function renderAnalytics(){$('#analytics').innerHTML=`<div class="page-head"><div><h1>Analytics</h1><p>Operational view of the AI support pipeline.</p></div></div><div class="analytics-grid"><div class="card"><small>Resolution rate</small><div class="big-num">${tickets.length?Math.round(tickets.filter(t=>t.status==='Resolved').length/tickets.length*100):0}%</div><span class="trend up">Based on current demo tickets</span><div class="progress" style="margin-top:20px"><i style="width:${tickets.length?Math.round(tickets.filter(t=>t.status==='Resolved').length/tickets.length*100):0}%"></i></div></div><div class="card"><small>Safe routing threshold</small><div class="big-num">90%</div><span class="trend up">Below threshold → human review</span><div class="progress" style="margin-top:20px"><i style="width:90%"></i></div></div><div class="card"><div class="card-title"><h3>AI pipeline quality</h3></div><div style="display:grid;gap:14px;margin-top:20px">${[['Classification',96],['Knowledge retrieval',92],['Solution generation',94],['Escalation routing',98]].map(x=>`<div><div class="metric"><span>${x[0]}</span><b>${x[1]}%</b></div><div class="progress"><i style="width:${x[1]}%"></i></div></div>`).join('')}</div></div><div class="card"><div class="card-title"><h3>Ticket categories</h3></div><div style="display:grid;gap:12px;margin-top:18px">${Object.entries(KB).map(([k,v])=>{let n=tickets.filter(t=>t.key===k).length;return `<div><div class="metric"><span>${v.category}</span><b>${n}</b></div><div class="progress"><i style="width:${Math.min(100,n*25)}%"></i></div></div>`}).join('')}</div></div></div>`}
function renderEscalations(){let es=tickets.filter(t=>t.status==='Escalated');$('#escalations').innerHTML=`<div class="page-head"><div><h1>Human Escalations</h1><p>Cases that SupportPilot deliberately did not claim to solve automatically.</p></div></div><div class="escalation-banner"><div><b>Human-in-the-loop protection</b><p>Low-confidence cases and critical business impact can be routed to support engineers.</p></div><span class="badge b-red">${es.length} pending</span></div><div class="card">${ticketTable(es)}</div>`}
function renderSettings(){$('#settings').innerHTML=`<div class="page-head"><div><h1>Settings</h1><p>Control the demo workflow and safety behavior.</p></div><button class="primary" onclick="save();toast('Settings saved')">Save changes</button></div><div class="settings-grid"><div class="card">${[['classification','Automatic classification','Classify every new ticket before resolution.'],['retrieval','RAG knowledge retrieval','Retrieve trusted support information before generating a response.'],['generation','Solution generation','Allow the Resolution Agent to produce troubleshooting guidance.'],['autoEscalate','Automatic escalation','Escalate when confidence is below the safe threshold.']].map(setting).join('')}</div><div class="card">${[['notifications','Ticket notifications','Show confirmation and status updates in the workspace.']].map(setting).join('')}<div class="setting-row"><div><b>Safe confidence threshold</b><small>Automatic resolution is only claimed at 90% confidence or above.</small></div><strong>90%</strong></div></div></div>`}
function setting(x){return `<div class="setting-row"><div><b>${x[1]}</b><small>${x[2]}</small></div><button class="switch ${settings[x[0]]?'on':''}" onclick="toggleSetting('${x[0]}')"><i></i></button></div>`}
$$('.nav').forEach(n=>n.onclick=()=>showPage(n.dataset.page));

// ---------------- JWT Authentication ----------------
// Authentication is handled by the FastAPI backend. The frontend stores only the JWT access token.
const API_BASE='http://127.0.0.1:8000';
let authUser=null;
function getToken(){return localStorage.getItem('sp_access_token')||'';}
function clearAuth(){localStorage.removeItem('sp_access_token');localStorage.removeItem('sp_user');localStorage.removeItem('sp_last_resolution');authUser=null;}
async function api(path,options={}){
  const headers=new Headers(options.headers||{});
  if(!headers.has('Content-Type') && options.body) headers.set('Content-Type','application/json');
  const token=getToken();
  if(token) headers.set('Authorization',`Bearer ${token}`);
  const response=await fetch(`${API_BASE}${path}`,{...options,headers});
  if(response.status===401){clearAuth();showLogin();throw new Error('AUTH_EXPIRED');}
  return response;
}
function currentUser(){return authUser || JSON.parse(localStorage.getItem('sp_user')||'null');}
function initials(name){return String(name||'User').split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase()||'U'}
function updateProfile(user){
  if(!user)return;
  const avatar=$('.avatar'), profile=$('.profile');
  if(avatar) avatar.textContent=initials(user.name);
  if(profile) profile.innerHTML=`<div class="avatar">${esc(initials(user.name))}</div><div><b>${esc(user.name)}</b><small>${esc(user.role||'Support User')}</small></div>`;
}
function showLogin(){
  $('#app').classList.add('hidden');$('#login').classList.remove('hidden');
  $('#loginForm').reset();setAuthMode('signin');
}
function openWorkspace(user){
  authUser=user;localStorage.setItem('sp_user',JSON.stringify(user));
  $('#login').classList.add('hidden');$('#app').classList.remove('hidden');
  updateProfile(user);render();toast(`Welcome, ${user.name.split(' ')[0]}!`);
}
function setAuthMode(mode){
  const signup=mode==='signup';
  $('#signInTab').classList.toggle('active',!signup);$('#signUpTab').classList.toggle('active',signup);
  $('#authTitle').textContent=signup?'Create your account':'Welcome back';
  $('#authSubtitle').textContent=signup?'Create a secure SupportPilot account':'Sign in to your AI support workspace';
  $$('.signup-only').forEach(el=>el.classList.toggle('hidden',!signup));
  $('#signupName').required=signup;$('#confirmPassword').required=signup;
  $('#password').autocomplete=signup?'new-password':'current-password';
  $('#authSubmit').innerHTML=signup?'Create account <span>→</span>':'Sign in <span>→</span>';
  $('#demoCredentials').classList.toggle('hidden',signup);$('#signupNote').classList.toggle('hidden',!signup);
}
$('#signInTab').onclick=()=>setAuthMode('signin');
$('#signUpTab').onclick=()=>setAuthMode('signup');
$('#loginForm').onsubmit=async e=>{
  e.preventDefault();
  const signup=$('#signUpTab').classList.contains('active');
  const email=$('#email').value.trim().toLowerCase();const password=$('#password').value;
  try{
    let response;
    if(signup){
      const name=$('#signupName').value.trim(),confirm=$('#confirmPassword').value;
      if(name.length<2)return toast('Please enter your full name.');
      if(password.length<6)return toast('Password must be at least 6 characters.');
      if(password!==confirm)return toast('Passwords do not match.');
      response=await fetch(`${API_BASE}/auth/signup`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,email,password})});
    }else{
      response=await fetch(`${API_BASE}/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password})});
    }
    const data=await response.json().catch(()=>({}));
    if(!response.ok)return toast(data.detail||'Authentication failed. Start the backend and try again.');
    localStorage.setItem('sp_access_token',data.access_token);
    localStorage.setItem('sp_user',JSON.stringify(data.user));
    $('#loginForm').reset();setAuthMode('signin');openWorkspace(data.user);
  }catch(_){toast('Backend is not running. Start the FastAPI server on port 8000.');}
};
$('#logout').onclick=()=>{clearAuth();showLogin();toast('Signed out successfully')};
$('#modal').onclick=e=>{if(e.target.id==='modal')closeModal()};

async function restoreSession(){
  const token=getToken();
  if(!token){showLogin();return;}
  try{
    const r=await api('/auth/me');
    if(!r.ok) throw new Error('AUTH_FAILED');
    const user=await r.json();
    authUser=user;localStorage.setItem('sp_user',JSON.stringify(user));
    let saved=localStorage.getItem('sp_last_resolution');if(saved){try{window.lastResolution=JSON.parse(saved)}catch(_) {}}
    $('#login').classList.add('hidden');$('#app').classList.remove('hidden');updateProfile(user);render();
  }catch(e){
    if(e.message!=='AUTH_EXPIRED'){clearAuth();showLogin();}
  }
}
restoreSession();

function toggleSetting(key){settings[key]=!settings[key];save();renderSettings();toast('Setting updated')}
