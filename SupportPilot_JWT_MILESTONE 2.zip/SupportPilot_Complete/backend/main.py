from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field
from typing import List, Optional
from pathlib import Path
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json
import os
import re
import secrets
import jwt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

BASE = Path(__file__).resolve().parent.parent
KB_PATH = BASE / "data" / "knowledge_base.json"
USERS_PATH = BASE / "data" / "users.json"

app = FastAPI(title="SupportPilot API", version="2.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

with open(KB_PATH, "r", encoding="utf-8") as f:
    KNOWLEDGE_BASE = json.load(f)

# JWT configuration. Set SUPPORTPILOT_JWT_SECRET in a real deployment.
JWT_SECRET = os.getenv("SUPPORTPILOT_JWT_SECRET", "supportpilot-dev-secret-change-this-in-production")
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_MINUTES = int(os.getenv("SUPPORTPILOT_ACCESS_TOKEN_MINUTES", "60"))
bearer_scheme = HTTPBearer(auto_error=False)

def _hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000)
    return f"pbkdf2_sha256$310000${salt.hex()}${derived.hex()}"

def _verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, iterations, salt_hex, digest_hex = encoded.split("$", 3)
        if scheme != "pbkdf2_sha256":
            return False
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(digest_hex)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iterations))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False

def _load_users():
    if not USERS_PATH.exists():
        USERS_PATH.write_text(json.dumps([{
            "name": "Admin User",
            "email": "admin@supportpilot.com",
            "password_hash": _hash_password("support123"),
            "role": "Support Admin"
        }], indent=2), encoding="utf-8")
    try:
        data = json.loads(USERS_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []

def _save_users(users):
    USERS_PATH.write_text(json.dumps(users, indent=2), encoding="utf-8")

USERS = _load_users()

def _create_token(user: dict) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user["email"],
        "name": user["name"],
        "role": user.get("role", "Support User"),
        "iat": now,
        "exp": now + timedelta(minutes=ACCESS_TOKEN_MINUTES),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)) -> dict:
    if not credentials or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        email = payload.get("sub")
        if not email:
            raise ValueError("Missing subject")
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError, ValueError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token", headers={"WWW-Authenticate": "Bearer"})
    user = next((u for u in USERS if u.get("email") == email), None)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User no longer exists", headers={"WWW-Authenticate": "Bearer"})
    return user

class SignupRequest(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: str = Field(min_length=5, max_length=160)
    password: str = Field(min_length=6, max_length=128)

class LoginRequest(BaseModel):
    email: str = Field(min_length=5, max_length=160)
    password: str = Field(min_length=1, max_length=128)

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: dict

class Ticket(BaseModel):
    title: str = Field(min_length=3)
    description: str = Field(min_length=3)
    priority: str = "Medium"
    category: Optional[str] = None

class RetrievalResult(BaseModel):
    id: str
    title: str
    category: str
    content: str
    score: float

class ResolutionResponse(BaseModel):
    status: str
    category: str
    confidence: float
    retrieved_documents: List[RetrievalResult]
    resolution: str
    escalation_reason: Optional[str] = None

texts = [d["title"] + " " + d["category"] + " " + d["content"] for d in KNOWLEDGE_BASE]
vectorizer = TfidfVectorizer(stop_words="english")
document_vectors = vectorizer.fit_transform(texts)

RULES = {
    "VPN / Network Issue": ["vpn", "virtual private", "vpn client"],
    "Password Reset": ["password", "forgot password", "reset password", "cannot sign in"],
    "Network Connectivity": ["network", "wifi", "internet", "connectivity", "ethernet", "dns"],
    "Software Troubleshooting": ["software", "application", "app", "install", "installation", "launch", "not opening"],
    "Hardware Problem": ["hardware", "laptop", "keyboard", "mouse", "monitor", "printer", "device"],
    "System Error": ["system error", "blue screen", "system failure", "crash", "operating system"],
}

def classify(text: str):
    t = text.lower()
    scores = {category: 0 for category in RULES}
    for category, words in RULES.items():
        for word in words:
            if word in t:
                scores[category] += 3 if len(word) > 6 else 2
    best_category, best_score = max(scores.items(), key=lambda x: x[1])
    if best_score == 0:
        return "System Error", 0.62, "No specific support intent matched"
    confidence = min(0.98, 0.90 + min(0.08, best_score * 0.02))
    return best_category, confidence, "Strong keyword and intent match"

def retrieve(query: str, top_k: int = 3):
    q = vectorizer.transform([query])
    scores = cosine_similarity(q, document_vectors)[0]
    ranked = scores.argsort()[::-1][:top_k]
    return [RetrievalResult(score=float(scores[i]), **{k: KNOWLEDGE_BASE[i][k] for k in ["id", "title", "category", "content"]}) for i in ranked if scores[i] > 0]

def generate_resolution(ticket: Ticket, docs: List[RetrievalResult]):
    if not docs:
        return "No sufficiently relevant knowledge-base information was found. Additional investigation is required."
    steps = []
    for doc in docs:
        for line in doc.content.splitlines():
            line = line.strip()
            if re.match(r"^\d+\.\s+", line):
                steps.append(re.sub(r"^\d+\.\s+", "", line))
    unique = list(dict.fromkeys(steps))[:6]
    if not unique:
        unique = ["Review the retrieved knowledge-base article and follow the approved troubleshooting procedure."]
    result = "Recommended Resolution:\n" + "\n".join(f"{i+1}. {s}" for i, s in enumerate(unique))
    result += "\n\nSources: " + ", ".join(f"{d.id} – {d.title}" for d in docs)
    return result


@app.post("/auth/signup", response_model=TokenResponse)
def signup(request: SignupRequest):
    email = request.email.strip().lower()
    if any(u.get("email", "").lower() == email for u in USERS):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = {"name": request.name.strip(), "email": email, "password_hash": _hash_password(request.password), "role": "Support User"}
    USERS.append(user)
    _save_users(USERS)
    token = _create_token(user)
    return TokenResponse(access_token=token, expires_in=ACCESS_TOKEN_MINUTES * 60, user={"name": user["name"], "email": user["email"], "role": user["role"]})

@app.post("/auth/login", response_model=TokenResponse)
def login(request: LoginRequest):
    email = request.email.strip().lower()
    user = next((u for u in USERS if u.get("email", "").lower() == email), None)
    if not user or not _verify_password(request.password, user.get("password_hash", "")):
        raise HTTPException(status_code=401, detail="Invalid email or password", headers={"WWW-Authenticate": "Bearer"})
    token = _create_token(user)
    return TokenResponse(access_token=token, expires_in=ACCESS_TOKEN_MINUTES * 60, user={"name": user["name"], "email": user["email"], "role": user.get("role", "Support User")})

@app.get("/auth/me")
def me(current_user: dict = Depends(get_current_user)):
    return {"name": current_user["name"], "email": current_user["email"], "role": current_user.get("role", "Support User")}

@app.get("/")
def root():
    return {"service": "SupportPilot API", "status": "online"}

@app.get("/health")
def health():
    return {"status": "healthy", "knowledge_base_documents": len(KNOWLEDGE_BASE)}

@app.get("/knowledge-base", response_model=List[dict])
def knowledge_base(current_user: dict = Depends(get_current_user)):
    return KNOWLEDGE_BASE

@app.post("/analyze", response_model=ResolutionResponse)
def analyze(ticket: Ticket, current_user: dict = Depends(get_current_user)):
    text = f"{ticket.title} {ticket.description}"
    category, confidence, reason = classify(text)
    docs = retrieve(text, top_k=3)
    # A safety threshold prevents unsupported automatic resolution.
    if confidence < 0.90 or not docs:
        return ResolutionResponse(status="ESCALATED", category=category, confidence=confidence, retrieved_documents=docs,
            resolution="SupportPilot could not safely claim an automatic resolution. Please route this case to human support for investigation.",
            escalation_reason=reason if confidence < 0.90 else "No relevant knowledge-base article was retrieved")
    return ResolutionResponse(status="RESOLVED", category=category, confidence=confidence, retrieved_documents=docs,
        resolution=generate_resolution(ticket, docs))
