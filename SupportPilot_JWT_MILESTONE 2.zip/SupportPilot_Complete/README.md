# SupportPilot – Complete AI Ticket Resolution Demo

SupportPilot is a college-project demo for an AI-powered IT support workflow.

## Main flow

1. Create a support ticket.
2. Analyze the title and description.
3. Classify the issue.
4. Retrieve relevant knowledge using TF-IDF + cosine similarity (RAG).
5. Add retrieved knowledge as context.
6. Generate numbered troubleshooting steps.
7. Mark the ticket as Resolved when it meets the safe threshold, otherwise Escalate to human support.

## Frontend

Open `frontend/index.html` in a browser. The frontend includes:
- JWT-secured Sign in / Create account
- Dashboard
- Create Ticket
- My Tickets
- Knowledge Base
- AI Agents
- Analytics
- Escalations
- Settings
- Post-ticket **Knowledge Retrieval & Resolution Generation** result page

### Post-ticket result

After clicking **Analyze & Submit Ticket**, the user is taken directly to a result screen containing:
- Ticket ID, title, description and priority
- Classification result
- Retrieval confidence
- Resolution confidence
- RAG workflow stages
- Generated solution titled **How to solve the problem / Recommended troubleshooting steps**
- Knowledge articles used
- Human escalation when the system cannot safely resolve the case

Authentication and AI analysis use the FastAPI backend. The browser stores the JWT access token and sends it as `Authorization: Bearer <token>` for protected API calls. A local RAG fallback remains only for the ticket-resolution UI if the analysis API is temporarily unavailable.

## Backend

```bash
cd backend
python -m pip install -r ../requirements.txt
python -m uvicorn main:app --reload --port 8000
```

Then open `frontend/index.html`.

## JWT authentication

The project now uses backend JWT authentication:
- `POST /auth/signup` creates a user and stores a salted PBKDF2-SHA256 password hash.
- `POST /auth/login` verifies the password and returns a signed HS256 JWT access token.
- `GET /auth/me` validates the token and returns the current user.
- `/analyze` and `/knowledge-base` are protected and require `Authorization: Bearer <token>`.
- Access tokens expire after 60 minutes by default.
- Set `SUPPORTPILOT_JWT_SECRET` before deployment; the bundled secret is for local college-demo use only.

### Demo account
Email: `admin@supportpilot.com`
Password: `support123`

New users can select **Create account**. Accounts are stored by the backend in `data/users.json` with password hashes; plaintext passwords are never stored.

## Notes

This is a demonstration implementation. It does not claim production-level accuracy or a real external LLM. The retrieval stage uses TF-IDF + cosine similarity and the resolution is generated from the retrieved knowledge base.


## Run the JWT version

From the project root on Windows:
```bat
scripts\run_backend.bat
```
Then open `frontend/index.html` in your browser. Keep the backend terminal running while using the application.

For a stronger local secret in PowerShell:
```powershell
$env:SUPPORTPILOT_JWT_SECRET="replace-with-a-long-random-secret"
python -m uvicorn backend.main:app --reload --port 8000
```
